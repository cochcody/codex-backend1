# TextBasedGame.py
# Author: Cody Cochran

# Function to show game instructions
def show_instructions():
    print(" King's Castle Adventure")
    print("Collect 6 items to win the game, or be defeated by the villain in the Throne Room.")
    print("Move commands: go North, go South, go East, go West")
    print("Add to Inventory: get 'item name'")
    print("----------------------------------")

# Function to show player's current status
def show_status(current_room, inventory, rooms):
    print(f"You are in the {current_room}")
    print(f"Inventory: {inventory}")
    if 'item' in rooms[current_room] and rooms[current_room]['item'] != 'Villain':
        print(f"You see a {rooms[current_room]['item']}")
    print("----------------------------------")

# Main function containing game logic
def main():
    # Dictionary linking rooms and items
    rooms = {
        'Courtyard': {'North': 'Royal Library', 'East': 'Dining Hall'},
        'Royal Library': {'South': 'Courtyard', 'East': 'Treasury', 'item': 'Ancient Sword'},
        'Dining Hall': {'West': 'Courtyard', 'North': 'Treasury', 'item': 'Enchanted Amulet'},
        'Treasury': {'West': 'Royal Library', 'South': 'Armory', 'item': 'Golden Coin Chest'},
        'Armory': {'North': 'Treasury', 'East': 'Barracks', 'item': 'Regal Sword'},
        'Barracks': {'West': 'Armory', 'South': 'Chapel', 'item': 'Battle Standard'},
        'Chapel': {'North': 'Barracks', 'East': 'Throne Room', 'item': 'Blessed Chalice'},
        'Throne Room': {'West': 'Chapel', 'item': 'Villain'}  # Villain room
    }

    inventory = []
    current_room = 'Courtyard'
    show_instructions()

    while True:
        show_status(current_room, inventory, rooms)
        move = input("Enter your move:\n").strip()

        # Handle movement
        if move.startswith("go "):
            direction = move[3:].capitalize()
            if direction in rooms[current_room]:
                current_room = rooms[current_room][direction]
                # Check for villain
                if 'item' in rooms[current_room] and rooms[current_room]['item'] == 'Villain':
                    if len(inventory) == 6:
                        print("🎉 You have collected all items and defeated the villain in the Throne Room!")
                    else:
                        print("💀 The villain has defeated you... GAME OVER!")
                    print("Thanks for playing King's Castle Adventure.")
                    break
            else:
                print("🚫 You can't go that way.")

        # Handle item collection
        elif move.startswith("get "):
            item_name = move[4:]
            if 'item' in rooms[current_room] and rooms[current_room]['item'].lower() == item_name.lower():
                if item_name not in inventory:
                    inventory.append(rooms[current_room]['item'])
                    print(f"✅ {item_name} added to inventory.")
                    del rooms[current_room]['item']
                else:
                    print("⚠️ You already have that item.")
            else:
                print(" No such item here.")

        # Invalid command
        else:
            print(" Invalid command. Try again.")

# Run the game
if __name__ == "__main__":
    main()